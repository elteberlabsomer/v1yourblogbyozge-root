import { demoPostsProvider } from '@/lib/content/providers/demo-posts-provider';

export const content = demoPostsProvider;
